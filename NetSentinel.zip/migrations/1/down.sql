
DROP INDEX idx_honeypot_services_active;
DROP TABLE honeypot_services;
DROP INDEX idx_alerts_created_at;
DROP INDEX idx_alerts_status;
DROP INDEX idx_alerts_severity;
DROP TABLE alerts;
DROP INDEX idx_threats_created_at;
DROP INDEX idx_threats_ip;
DROP INDEX idx_threats_severity;
DROP TABLE threats;
