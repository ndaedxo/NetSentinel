
CREATE TABLE threats (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ip_address TEXT NOT NULL,
  country_code TEXT,
  threat_score INTEGER NOT NULL,
  severity TEXT NOT NULL,
  threat_type TEXT NOT NULL,
  description TEXT,
  honeypot_service TEXT,
  is_blocked BOOLEAN DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_threats_severity ON threats(severity);
CREATE INDEX idx_threats_ip ON threats(ip_address);
CREATE INDEX idx_threats_created_at ON threats(created_at);

CREATE TABLE alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  severity TEXT NOT NULL,
  status TEXT DEFAULT 'new',
  description TEXT,
  threat_id INTEGER,
  is_acknowledged BOOLEAN DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_alerts_severity ON alerts(severity);
CREATE INDEX idx_alerts_status ON alerts(status);
CREATE INDEX idx_alerts_created_at ON alerts(created_at);

CREATE TABLE honeypot_services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  port INTEGER NOT NULL,
  protocol TEXT NOT NULL,
  is_active BOOLEAN DEFAULT 1,
  connection_count INTEGER DEFAULT 0,
  last_connection_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_honeypot_services_active ON honeypot_services(is_active);
