
DROP INDEX idx_reports_type;
DROP INDEX idx_incident_timeline_incident;
DROP INDEX idx_incidents_status;
DROP INDEX idx_network_connections_devices;
DROP INDEX idx_network_devices_ip;
DROP TABLE reports;
DROP TABLE incident_timeline;
DROP TABLE incidents;
DROP TABLE network_connections;
DROP TABLE network_devices;
