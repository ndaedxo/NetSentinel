
CREATE TABLE network_devices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hostname TEXT NOT NULL,
  ip_address TEXT NOT NULL,
  device_type TEXT NOT NULL,
  os_info TEXT,
  mac_address TEXT,
  vendor TEXT,
  location TEXT,
  is_online BOOLEAN DEFAULT 1,
  last_seen_at DATETIME,
  vulnerability_score INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE network_connections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_device_id INTEGER NOT NULL,
  destination_device_id INTEGER NOT NULL,
  source_port INTEGER,
  destination_port INTEGER,
  protocol TEXT NOT NULL,
  connection_state TEXT DEFAULT 'active',
  bandwidth_usage INTEGER DEFAULT 0,
  packet_count INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE incidents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  severity TEXT NOT NULL,
  status TEXT DEFAULT 'open',
  category TEXT NOT NULL,
  description TEXT,
  affected_systems TEXT,
  assigned_to TEXT,
  response_plan TEXT,
  containment_actions TEXT,
  recovery_actions TEXT,
  lessons_learned TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE incident_timeline (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  incident_id INTEGER NOT NULL,
  action_type TEXT NOT NULL,
  description TEXT NOT NULL,
  performed_by TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  report_type TEXT NOT NULL,
  status TEXT DEFAULT 'generating',
  parameters TEXT,
  file_path TEXT,
  generated_by TEXT,
  scheduled_for DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_network_devices_ip ON network_devices(ip_address);
CREATE INDEX idx_network_connections_devices ON network_connections(source_device_id, destination_device_id);
CREATE INDEX idx_incidents_status ON incidents(status);
CREATE INDEX idx_incident_timeline_incident ON incident_timeline(incident_id);
CREATE INDEX idx_reports_type ON reports(report_type);
