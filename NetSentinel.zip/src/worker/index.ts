import { Hono } from "hono";
import { cors } from "hono/cors";
import { getCookie, setCookie } from "hono/cookie";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";

const app = new Hono<{ Bindings: Env }>();

app.use("/*", cors());

// Auth endpoints
app.get("/api/oauth/google/redirect_url", async (c) => {
  const env = c.env as Env & {
    MOCHA_USERS_SERVICE_API_URL: string;
    MOCHA_USERS_SERVICE_API_KEY: string;
  };
  const redirectUrl = await getOAuthRedirectUrl("google", {
    apiUrl: env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const env = c.env as Env & {
    MOCHA_USERS_SERVICE_API_URL: string;
    MOCHA_USERS_SERVICE_API_KEY: string;
  };
  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60,
  });

  return c.json({ success: true }, 200);
});

app.get("/api/users/me", authMiddleware, async (c) => {
  return c.json(c.get("user"));
});

app.get("/api/logout", async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === "string") {
    const env = c.env as Env & {
      MOCHA_USERS_SERVICE_API_URL: string;
      MOCHA_USERS_SERVICE_API_KEY: string;
    };
    await deleteSession(sessionToken, {
      apiUrl: env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, "", {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Dashboard metrics
app.get("/api/metrics", authMiddleware, async (c) => {
  const now = new Date();
  const today = now.toISOString().split("T")[0];

  // Get threat counts
  const { results: threats } = await c.env.DB.prepare(
    "SELECT COUNT(*) as total FROM threats"
  ).all();

  const { results: todayThreats } = await c.env.DB.prepare(
    "SELECT COUNT(*) as total FROM threats WHERE DATE(created_at) = ?"
  )
    .bind(today)
    .all();

  const { results: criticalThreats } = await c.env.DB.prepare(
    "SELECT COUNT(*) as total FROM threats WHERE severity = 'critical'"
  ).all();

  const { results: blockedIps } = await c.env.DB.prepare(
    "SELECT COUNT(DISTINCT ip_address) as total FROM threats WHERE is_blocked = 1"
  ).all();

  return c.json({
    totalEvents: threats[0]?.total || 0,
    activeThreats: criticalThreats[0]?.total || 0,
    blockedIps: blockedIps[0]?.total || 0,
    todayThreats: todayThreats[0]?.total || 0,
  });
});

// Recent threats
app.get("/api/threats/recent", authMiddleware, async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM threats ORDER BY created_at DESC LIMIT 10"
  ).all();

  return c.json(results);
});

// Threat timeline (last 24 hours)
app.get("/api/threats/timeline", authMiddleware, async (c) => {
  const { results } = await c.env.DB.prepare(`
    SELECT 
      strftime('%H:00', created_at) as hour,
      COUNT(*) as count,
      severity
    FROM threats
    WHERE created_at >= datetime('now', '-24 hours')
    GROUP BY hour, severity
    ORDER BY hour
  `).all();

  return c.json(results);
});

// Honeypot services
app.get("/api/honeypots", authMiddleware, async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM honeypot_services ORDER BY port"
  ).all();

  return c.json(results);
});

// Active alerts
app.get("/api/alerts/active", authMiddleware, async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM alerts WHERE status != 'resolved' ORDER BY created_at DESC LIMIT 5"
  ).all();

  return c.json(results);
});

// System health
app.get("/api/health", authMiddleware, async (c) => {
  return c.json({
    services: [
      { name: "Kafka", status: "running" },
      { name: "Redis", status: "running" },
      { name: "ML Engine", status: "running" },
      { name: "Elasticsearch", status: "degraded" },
      { name: "InfluxDB", status: "running" },
    ],
  });
});

// All threats (for threat intelligence page)
app.get("/api/threats/all", authMiddleware, async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM threats ORDER BY created_at DESC"
  ).all();

  return c.json(results);
});

// Block IP
app.post("/api/threats/block", authMiddleware, async (c) => {
  const { ip_address } = await c.req.json();

  if (!ip_address) {
    return c.json({ error: "IP address is required" }, 400);
  }

  await c.env.DB.prepare(
    "UPDATE threats SET is_blocked = 1, updated_at = CURRENT_TIMESTAMP WHERE ip_address = ?"
  )
    .bind(ip_address)
    .run();

  return c.json({ success: true });
});

// Toggle honeypot service
app.post("/api/honeypots/toggle", authMiddleware, async (c) => {
  const { id, is_active } = await c.req.json();

  if (id === undefined || is_active === undefined) {
    return c.json({ error: "ID and is_active are required" }, 400);
  }

  await c.env.DB.prepare(
    "UPDATE honeypot_services SET is_active = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  )
    .bind(is_active, id)
    .run();

  return c.json({ success: true });
});

// All alerts
app.get("/api/alerts/all", authMiddleware, async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM alerts ORDER BY created_at DESC"
  ).all();

  return c.json(results);
});

// Acknowledge alert
app.post("/api/alerts/acknowledge", authMiddleware, async (c) => {
  const { id } = await c.req.json();

  if (!id) {
    return c.json({ error: "Alert ID is required" }, 400);
  }

  await c.env.DB.prepare(
    "UPDATE alerts SET is_acknowledged = 1, status = 'acknowledged', updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  )
    .bind(id)
    .run();

  return c.json({ success: true });
});

// Resolve alert
app.post("/api/alerts/resolve", authMiddleware, async (c) => {
  const { id } = await c.req.json();

  if (!id) {
    return c.json({ error: "Alert ID is required" }, 400);
  }

  await c.env.DB.prepare(
    "UPDATE alerts SET status = 'resolved', updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  )
    .bind(id)
    .run();

  return c.json({ success: true });
});

// Network topology
app.get("/api/network/topology", authMiddleware, async (c) => {
  const { results: devices } = await c.env.DB.prepare(
    "SELECT * FROM network_devices ORDER BY hostname"
  ).all();

  const { results: connections } = await c.env.DB.prepare(
    "SELECT * FROM network_connections ORDER BY created_at DESC"
  ).all();

  return c.json({
    devices,
    connections
  });
});

// Incidents
app.get("/api/incidents", authMiddleware, async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM incidents ORDER BY created_at DESC"
  ).all();

  return c.json(results);
});

// Incident timeline
app.get("/api/incidents/:id/timeline", authMiddleware, async (c) => {
  const incidentId = c.req.param('id');
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM incident_timeline WHERE incident_id = ? ORDER BY created_at DESC"
  )
    .bind(incidentId)
    .all();

  return c.json(results);
});

// Update incident status
app.post("/api/incidents/:id/status", authMiddleware, async (c) => {
  const incidentId = c.req.param('id');
  const { status } = await c.req.json();

  if (!status) {
    return c.json({ error: "Status is required" }, 400);
  }

  await c.env.DB.prepare(
    "UPDATE incidents SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  )
    .bind(status, incidentId)
    .run();

  // Add timeline entry
  await c.env.DB.prepare(
    "INSERT INTO incident_timeline (incident_id, action_type, description, performed_by) VALUES (?, ?, ?, ?)"
  )
    .bind(incidentId, 'status_change', `Status changed to ${status}`, 'System')
    .run();

  return c.json({ success: true });
});

// Reports
app.get("/api/reports", authMiddleware, async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM reports ORDER BY created_at DESC"
  ).all();

  return c.json(results);
});

// Generate report
app.post("/api/reports/generate", authMiddleware, async (c) => {
  const { title, report_type, parameters } = await c.req.json();

  if (!title || !report_type) {
    return c.json({ error: "Title and report_type are required" }, 400);
  }

  const user = c.get("user");
  const generated_by = user?.google_user_data?.name || user?.email || 'Unknown';

  await c.env.DB.prepare(
    "INSERT INTO reports (title, report_type, status, parameters, generated_by) VALUES (?, ?, ?, ?, ?)"
  )
    .bind(title, report_type, 'generating', parameters || null, generated_by)
    .run();

  return c.json({ success: true });
});

export default app;
