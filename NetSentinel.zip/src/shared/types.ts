import z from "zod";

export const ThreatSchema = z.object({
  id: z.number(),
  ip_address: z.string(),
  country_code: z.string().nullable(),
  threat_score: z.number(),
  severity: z.enum(["low", "medium", "high", "critical"]),
  threat_type: z.string(),
  description: z.string().nullable(),
  honeypot_service: z.string().nullable(),
  is_blocked: z.number().int(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type ThreatType = z.infer<typeof ThreatSchema>;

export const AlertSchema = z.object({
  id: z.number(),
  title: z.string(),
  severity: z.enum(["low", "medium", "high", "critical"]),
  status: z.enum(["new", "acknowledged", "resolved"]),
  description: z.string().nullable(),
  threat_id: z.number().nullable(),
  is_acknowledged: z.number().int(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type AlertType = z.infer<typeof AlertSchema>;

export const HoneypotServiceSchema = z.object({
  id: z.number(),
  name: z.string(),
  port: z.number(),
  protocol: z.string(),
  is_active: z.number().int(),
  connection_count: z.number(),
  last_connection_at: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type HoneypotServiceType = z.infer<typeof HoneypotServiceSchema>;

export interface DashboardMetrics {
  totalEvents: number;
  activeThreats: number;
  blockedIps: number;
  todayThreats: number;
}

export interface SystemHealthService {
  name: string;
  status: "running" | "degraded" | "error";
}

export const NetworkDeviceSchema = z.object({
  id: z.number(),
  hostname: z.string(),
  ip_address: z.string(),
  device_type: z.string(),
  os_info: z.string().nullable(),
  mac_address: z.string().nullable(),
  vendor: z.string().nullable(),
  location: z.string().nullable(),
  is_online: z.number().int(),
  last_seen_at: z.string().nullable(),
  vulnerability_score: z.number(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type NetworkDeviceType = z.infer<typeof NetworkDeviceSchema>;

export const NetworkConnectionSchema = z.object({
  id: z.number(),
  source_device_id: z.number(),
  destination_device_id: z.number(),
  source_port: z.number().nullable(),
  destination_port: z.number().nullable(),
  protocol: z.string(),
  connection_state: z.string(),
  bandwidth_usage: z.number(),
  packet_count: z.number(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type NetworkConnectionType = z.infer<typeof NetworkConnectionSchema>;

export const IncidentSchema = z.object({
  id: z.number(),
  title: z.string(),
  severity: z.enum(["low", "medium", "high", "critical"]),
  status: z.enum(["open", "investigating", "contained", "resolved", "closed"]),
  category: z.string(),
  description: z.string().nullable(),
  affected_systems: z.string().nullable(),
  assigned_to: z.string().nullable(),
  response_plan: z.string().nullable(),
  containment_actions: z.string().nullable(),
  recovery_actions: z.string().nullable(),
  lessons_learned: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type IncidentType = z.infer<typeof IncidentSchema>;

export const IncidentTimelineSchema = z.object({
  id: z.number(),
  incident_id: z.number(),
  action_type: z.string(),
  description: z.string(),
  performed_by: z.string().nullable(),
  created_at: z.string(),
});

export type IncidentTimelineType = z.infer<typeof IncidentTimelineSchema>;

export const ReportSchema = z.object({
  id: z.number(),
  title: z.string(),
  report_type: z.string(),
  status: z.enum(["generating", "completed", "failed", "scheduled"]),
  parameters: z.string().nullable(),
  file_path: z.string().nullable(),
  generated_by: z.string().nullable(),
  scheduled_for: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type ReportType = z.infer<typeof ReportSchema>;

export interface NetworkTopology {
  devices: NetworkDeviceType[];
  connections: NetworkConnectionType[];
}
