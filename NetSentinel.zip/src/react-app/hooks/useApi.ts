import { useState, useEffect } from "react";

export function useApi<T>(endpoint?: string, refreshInterval?: number) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(!!endpoint);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async <U = any>(url?: string): Promise<U> => {
    const targetUrl = url || endpoint;
    if (!targetUrl) {
      throw new Error("No endpoint provided");
    }

    try {
      const response = await fetch(targetUrl);
      if (!response.ok) {
        throw new Error("Failed to fetch data");
      }
      const result = await response.json();
      
      if (url === endpoint || !url) {
        setData(result);
        setError(null);
      }
      
      return result;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Unknown error";
      if (url === endpoint || !url) {
        setError(errorMessage);
      }
      throw err;
    } finally {
      if (url === endpoint || !url) {
        setLoading(false);
      }
    }
  };

  const postData = async <U = any>(url: string, body: any): Promise<U> => {
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      });
      
      if (!response.ok) {
        throw new Error("Failed to post data");
      }
      
      return await response.json();
    } catch (err) {
      throw err;
    }
  };

  useEffect(() => {
    if (endpoint) {
      fetchData();

      if (refreshInterval) {
        const interval = setInterval(() => fetchData(), refreshInterval);
        return () => clearInterval(interval);
      }
    }
  }, [endpoint, refreshInterval]);

  return { data, loading, error, refetch: () => fetchData(), fetchData, postData };
}
